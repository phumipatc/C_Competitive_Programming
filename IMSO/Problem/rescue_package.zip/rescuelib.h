#ifndef RESCUELIB_H_INCLUDED
#define RESCUELIB_H_INCLUDED

void get_size(int &R, int &C);
int drop_robot(int r, int c);
void answer(int r, int c);

#endif // RESCUELIB_H_INCLUDED
